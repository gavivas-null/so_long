# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 2.x.x   | ✅                 |
| 1.0.x   | ❌                 |

## Reporting a Vulnerability

For security issues please refrain from opening an issue!
Instead write an email to [main@w2wizard.dev](mailto:main@w2wizard.dev)
